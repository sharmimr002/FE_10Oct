import React from 'react';
import { Outlet } from 'react-router-dom';
import logo from '../assets/logo-color.png';
import { useNavigate, Link } from 'react-router-dom';

function Layout() {
  const navigate = useNavigate();
  const handleHomeClick=()=>{
    const access = localStorage.getItem('access_token');
    if(!access) navigate('/');
    else navigate('/createTicket')
  }
  return (
    <div>
      <header className='header'>
        <div className={'headofLayout'}>
            <img src={logo} style={{'width':'300px', 'height':'250px'}} onClick={handleHomeClick} className='furnifixLogo'/>
        
        
        <nav className='navBar'>
          <ul>
            <li><Link style={{
        color: 'black',
        textDecoration: 'none',
        fontWeight: 'bold',margin: '5px'
      }} to="/createUser">Create User</Link></li>
            <li><Link style={{
        color: 'black',
        textDecoration: 'none',
        fontWeight: 'bold',margin: '5px'
      }} to="/createTicket">Create Ticket</Link></li>
      {/* <li className="dropdown">
          <li><Link to="#" className="dropbtn">Services</Link></li>
          <div className="dropdown-content">
            <Link to="/design">Design</Link>
            <Link to="/development">Development</Link>
            <Link to="/marketing">Marketing</Link>
          </div>
        </li> */}
        <li><Link style={{
        color: 'black',
        textDecoration: 'none',
        fontWeight: 'bold',margin: '5px'
      }} to="/displayTickets">DisplayTickets</Link></li>
            <li><Link style={{
        color: 'black',
        textDecoration: 'none',
        fontWeight: 'bold',margin: '5px'
      }} to="/logout">LogOut</Link></li>
          </ul>
        </nav></div>
      </header>
      <main>
        <Outlet />
      </main>
    </div>
  );
}

export default Layout;